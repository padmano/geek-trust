/**
 * 
 */
package geektrust.challenge.cricket.rungenerator;

/**
 * @author Padmanabhan M
 *
 */
public interface RunsGenerator {

	abstract Integer generateRun();
}
