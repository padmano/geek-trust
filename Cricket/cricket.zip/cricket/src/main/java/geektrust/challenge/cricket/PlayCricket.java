package geektrust.challenge.cricket;

import java.io.FileNotFoundException;
import java.util.Map;
import java.util.logging.Logger;

import geektrust.challenge.cricket.exception.FieldNotPresentException;
import geektrust.challenge.cricket.pojo.MatchDetails;
import geektrust.challenge.cricket.pojo.Player;
import geektrust.challenge.cricket.utils.CricketUtils;

/**
 * Let's Play Cricket
 *
 */
public class PlayCricket {

	private static final Logger logger = Logger.getLogger(PlayCricket.class.getName());

	public static void main(String[] args) {

		try {
			MatchDetails matchDetails = matchDetails = CricketUtils.createMatchDetails("match");
			Map<Integer, Player> playerList = CricketUtils.createPlayerList("player");
			
			
			for (int i = 0; i < afterMatch.size(); i++) {
				Player player = afterMatch.get(i);
				System.out.println(player.getName() + " " + player.getTotalRunsScored() + (player.getIsOut() ? "" : "*")
						+ "(" + player.getTotalBallsFaced() + ")");
			}
			
			
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (FieldNotPresentException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}
}
