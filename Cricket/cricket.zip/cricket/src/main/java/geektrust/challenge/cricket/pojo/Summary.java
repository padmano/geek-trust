/**
 * 
 */
package geektrust.challenge.cricket.pojo;

/**
 * @author Padmanabhan M
 *
 */
public class Summary {
	
	private Integer totalRuns;
	private String winningTeam;
	private Integer playerLeft;
	private Integer ballLeft;
	/**
	 * @return the winningTeam
	 */
	public String getWinningTeam() {
		return winningTeam;
	}
	/**
	 * @param winningTeam the winningTeam to set
	 */
	public void setWinningTeam(String winningTeam) {
		this.winningTeam = winningTeam;
	}
	/**
	 * @return the playerLeft
	 */
	public Integer getPlayerLeft() {
		return playerLeft;
	}
	/**
	 * @param playerLeft the playerLeft to set
	 */
	public void setPlayerLeft(Integer playerLeft) {
		this.playerLeft = playerLeft;
	}
	/**
	 * @return the ballLeft
	 */
	public Integer getBallLeft() {
		return ballLeft;
	}
	/**
	 * @param ballLeft the ballLeft to set
	 */
	public void setBallLeft(Integer ballLeft) {
		this.ballLeft = ballLeft;
	}
	
	

}
