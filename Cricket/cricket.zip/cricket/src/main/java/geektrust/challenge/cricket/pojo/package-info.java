/**
 * 
 */
/**
 * @author Padmanabhan M
 *
 */
package geektrust.challenge.cricket.pojo;