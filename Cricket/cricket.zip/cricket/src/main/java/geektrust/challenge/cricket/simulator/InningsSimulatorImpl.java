/**
 * 
 */
package geektrust.challenge.cricket.simulator;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import geektrust.challenge.cricket.pojo.Commentary;
import geektrust.challenge.cricket.pojo.InningsResult;
import geektrust.challenge.cricket.pojo.MatchDetails;
import geektrust.challenge.cricket.pojo.Player;
import geektrust.challenge.cricket.utils.CricketUtils;

/**
 * @author Padmanabhan M
 *
 */
public class InningsSimulatorImpl implements InningsSimulator {

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * geektrust.challenge.cricket.simulator.InningsSimulator#simulateInnings(java.
	 * util.Map, geektrust.challenge.cricket.pojo.MatchDetails)
	 */
	public InningsResult simulateInningsAgainstTarget(Map<Integer, Player> players, MatchDetails matchDetails) {
		InningsResult result = new InningsResult();
		try {

			Integer targetRuns = matchDetails.getTargetRuns();
			Integer totalOvers = matchDetails.getTargetOvers();
			Integer balls = matchDetails.getBallsPerOver() * totalOvers;

			Player striker = players.get(1);
			Player nonStriker = players.get(2);
			Integer playerStrike = 3;

			Integer totalRuns = 0;

			Integer teamSize = players.size();

			Integer currentOver = 0;

			List<Player> afterMatch = new ArrayList<Player>();
			System.out.println("\n" + totalOvers + " overs left. " + targetRuns + " runs to win.\n");
			for (int currentBall = 1; currentBall <= balls; currentBall++) {

				Integer currentRun = striker.scoreRun();

				striker.setTotalBallsFaced(striker.getTotalBallsFaced() + 1);

				if (currentRun > 0) {
					striker.setTotalRunsScored(striker.getTotalRunsScored() + currentRun);
					totalRuns = totalRuns + currentRun;
				}
				if (currentRun < 0) {
					if (currentBall % 6 == 0)
						currentOver++;
					System.out.println(currentOver + "." + (currentBall % 6 == 0 ? 6 : (currentBall % 6)) + " "
							+ striker.getName() + " is out.");
					striker.setIsOut(Boolean.TRUE);
					afterMatch.add(striker);
					if (playerStrike > teamSize) {
						afterMatch.add(nonStriker);
						break;
					}
					striker = players.get(playerStrike);
					playerStrike++;
					continue;
				}

				System.out.println(currentOver + "." + (currentBall % 6 == 0 ? 6 : (currentBall % 6)) + " "
						+ striker.getName() + " scores " + currentRun + " " + (currentRun > 1 ? "runs." : "run."));
				if (totalRuns >= targetRuns) {
					System.out.println("Final Score :" + totalRuns + " - " + afterMatch.size());
					afterMatch.add(striker);
					afterMatch.add(nonStriker);
					System.out.println("\nLengaluru Won by " + (teamSize - playerStrike) + " wicket  and "
							+ (balls - currentBall) + " balls remaining.\n");
					break;
				}

				if (currentRun % 2 == 1) {
					List<Player> swappedList = new ArrayList<Player>();
					swappedList = CricketUtils.rotateStrike(striker, nonStriker);
					striker = swappedList.get(0);
					nonStriker = swappedList.get(1);
				}

				if (currentBall % 6 == 0) {
					List<Player> swappedList = new ArrayList<Player>();
					currentOver++;
					System.out.println(
							"\n" + (totalOvers - currentOver) + ((totalOvers - currentOver) > 1 ? " overs" : " over")
									+ " left. " + (targetRuns - totalRuns)
									+ ((targetRuns - totalRuns) > 1 ? " runs" : " run") + " to win.\n");
					swappedList = CricketUtils.rotateStrike(striker, nonStriker);
					striker = swappedList.get(0);
					nonStriker = swappedList.get(1);
				}
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return result;
	}

	/* Simulate an innings until last man standing or running out of balls.
	 * (non-Javadoc)
	 * 
	 * @see
	 * geektrust.challenge.cricket.simulator.InningsSimulator#simulateInnings(java.
	 * util.Map, geektrust.challenge.cricket.pojo.MatchDetails)
	 */
	public InningsResult simulateInnings(Map<Integer, Player> players, MatchDetails matchDetails) {

		InningsResult inningsResult = new InningsResult();
		Commentary comment;
		List<Commentary> commentaryList = new ArrayList<Commentary>();
		List<Player> playerList = new ArrayList<Player>();

			Player striker = players.get(1);
			Player nonStriker = players.get(2);

			Integer playerDown = 2;
			Integer currentRun = 0;
			Integer totalRun = 0;

			Integer totalBalls = matchDetails.getBallsPerOver() * matchDetails.getTargetOvers();

			Integer teamSize = players.size();
			List<Player> swapPlayerList ;
			for (int currentBall = 1; currentBall <= totalBalls; currentBall++) {

				currentRun = striker.scoreRun();

				striker.setTotalBallsFaced(striker.getTotalBallsFaced() + 1);

				comment = new Commentary(currentBall, striker.getName(), currentRun);

				if (currentRun > 0) {
					striker.setTotalRunsScored(striker.getTotalRunsScored() + currentRun);
					totalRun = totalRun + currentRun;
				}

				if ((currentRun % 2 == 1 || currentBall % 6 == 0) && !(currentRun % 2 == 1 && currentBall % 6 == 0)) {
					swapPlayerList = CricketUtils.rotateStrike(striker, nonStriker);
					striker = swapPlayerList.get(0);
					nonStriker = swapPlayerList.get(1);
				}

				if (currentRun < 0) {
					playerDown++;
					striker.setIsOut(Boolean.TRUE);
					playerList.add(striker);
					if (playerDown <= teamSize) {
						striker = players.get(playerDown);
					} else {
						playerList.add(striker);
						playerList.add(nonStriker);
						break;
					}

				}
				commentaryList.add(comment);
			}
		

		inningsResult.setCommentary(commentaryList);
		inningsResult.setPlayerList(playerList);
		return inningsResult;
	}

}
