/**
 * 
 */
package geektrust.challenge.cricket;

import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

/**
 * @author Padmanabhan M
 *
 */
public class PlayCricketTest {

	/**
	 * @throws java.lang.Exception
	 */
	private Map<>
	@BeforeClass
	public static void setUpBeforeClass() throws Exception {
	}

	/**
	 * @throws java.lang.Exception
	 */
	@Before
	public void setUp() throws Exception {
	}

	/**
	 * Test method for {@link geektrust.challenge.cricket.PlayCricket#main(java.lang.String[])}.
	 */
	@Test
	public void testMain() {
		fail("Not yet implemented"); // TODO
	}

}
